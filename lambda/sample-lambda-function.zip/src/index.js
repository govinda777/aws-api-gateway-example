
exports.handler = async (event) => {
    return {
        message: 'Recieved an event',
        event
    }
}